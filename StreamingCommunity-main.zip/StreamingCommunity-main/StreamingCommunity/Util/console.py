# 24.02.24

from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.table import Table
from rich.text import Text


# Variable
msg = Prompt()
console = Console()

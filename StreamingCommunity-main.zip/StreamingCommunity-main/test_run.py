# 26.11.24

from StreamingCommunity.run import main

main()